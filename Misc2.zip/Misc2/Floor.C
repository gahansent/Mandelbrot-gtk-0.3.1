#include <iostream>
#include <cmath>

using std::cout;
using std::cin;
using std::endl;


int main()
{
double bob;
double steve;
cout << "Please enter a number to take the floor of" << endl;
cin >> steve;
cout << "The floor of steve is: " << floor (steve) << endl;

cout << "Please enter a number to take the ceiling of" << endl;
cin >> bob;
cout << "The ceiling of steve is: " << ceil (bob) << endl;
}
