
#ifndef __STOREDRAWING__
#define __STOREDRAWING__

#include "interface.h"
void store_drawing_show(struct winctl *w);

#endif /* __STOREDRAWING__ */

